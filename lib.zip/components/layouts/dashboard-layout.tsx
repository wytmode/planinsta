//
//  Shim file ‒ makes sure there’s a default export at the expected path
//
export { DashboardLayout as default } from "../dashboard-layout"
