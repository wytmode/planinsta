// components/PaymentFormClient.tsx
"use client";

import React, { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { loadRazorpay } from "@/lib/loadRazorpay";

export default function PaymentFormClient() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const amount = Number(searchParams.get("amount") || 1); // rupees
  const [orderId, setOrderId] = useState<string | null>(null);

  async function onRazorpaySuccess(response: any) {
    try {
      await fetch("/api/razorpay/record-payment", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          razorpay_order_id: response.razorpay_order_id,
          razorpay_payment_id: response.razorpay_payment_id,
          currency: "INR",
          status: "captured",
        }),
      });
    } catch (err) {
      console.error("⚠️ Failed to record payment:", err);
    }
    router.replace("/plan-builder?paid=true");
  }

  // Create order on server (server converts rupees -> paise)
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/razorpay/create-order", {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ amount }),
        });
        const data = await res.json();
        if (data.id) setOrderId(data.id);
        else throw new Error(data?.error || "No order id returned");
      } catch (err) {
        console.error("Order creation failed", err);
      }
    })();
  }, [amount]);

  // Open Razorpay only after SDK is loaded AND we have an order
  useEffect(() => {
    if (!orderId) return;
    (async () => {
      try {
        const Razorpay = await loadRazorpay();
        if (typeof Razorpay !== "function") throw new Error("Razorpay SDK not available");

        const rzp = new Razorpay({
          key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || process.env.NEXT_PUBLIC_RAZORPAY_KEY,
          order_id: orderId,             // amount comes from the order
          name: "WytMode",
          currency: "INR",
          handler: onRazorpaySuccess,
          prefill: { name: "", email: "" },
          theme: { color: "#0C4A6E" },
        });

        rzp.on("payment.failed", (resp: any) => {
          console.error("payment.failed", resp);
          alert("Payment failed. Please try again.");
        });

        rzp.open();
      } catch (e) {
        console.error(e);
        alert("Could not start payment. Please refresh and try again.");
      }
    })();
  }, [orderId]);

  return (
    <div className="h-screen flex items-center justify-center bg-gray-100">
      {!orderId ? <p className="text-lg">Preparing payment...</p> : <p className="text-lg">Opening checkout...</p>}
    </div>
  );
}
